const AIRTABLE_BASE_ID = 'appcwvcnVuHI9TMdA';
const AIRTABLE_TABLE_ID = 'tbl6oiAmXfM1SFzT8';

const FIELD_IDS = [
  'fldl6RM0TkX4GFrZF', // Shipment ID
  'fldLwZ53Zc4MO59OU', // Shipment Reference (LI ref)
  'fldLnyv6M7vjg5sEg', // Shipping Destination (linked)
  'fldQUXBo2smwtjFgX', // Shipment Status
  'fldBdrLERHs7kK6L9', // Current ETA to Warehouse
  'fldfPbJDbTWy4ZHec', // Confirmed Freight Type
  'fldB1m2fWiZobPVeM', // Total Units on Shipment
  'fldJtOiIWBFRbrDpD', // Total Units Delivered
];

export async function onRequest(context) {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };

  if (context.request.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  // AIRTABLE_API_KEY is set in Cloudflare Pages → Settings → Environment Variables
  const apiKey = context.env.AIRTABLE_API_KEY;

  if (!apiKey) {
    return new Response(
      JSON.stringify({ error: 'AIRTABLE_API_KEY environment variable is not set.' }),
      { status: 500, headers: corsHeaders }
    );
  }

  try {
    const allRecords = [];
    let offset = null;

    do {
      const params = new URLSearchParams();
      FIELD_IDS.forEach(id => params.append('fields[]', id));
      params.set('pageSize', '100');
      if (offset) params.set('offset', offset);

      const url = `https://api.airtable.com/v0/${AIRTABLE_BASE_ID}/${AIRTABLE_TABLE_ID}?${params}`;

      const response = await fetch(url, {
        headers: { Authorization: `Bearer ${apiKey}` },
      });

      if (!response.ok) {
        const err = await response.text();
        throw new Error(`Airtable API error ${response.status}: ${err}`);
      }

      const data = await response.json();
      allRecords.push(...data.records);
      offset = data.offset || null;
    } while (offset);

    // Normalise records
    const shipments = allRecords.map(rec => {
      const f = rec.cellValuesByFieldId;

      // Destination: linked record array → first record name
      const destLinks = f['fldLnyv6M7vjg5sEg'] || [];
      const dest = Array.isArray(destLinks) && destLinks.length > 0
        ? (destLinks[0].name || '').trim()
        : '';

      // Freight: lookup returns nested object
      let freight = '';
      const freightRaw = f['fldfPbJDbTWy4ZHec'];
      if (freightRaw) {
        if (typeof freightRaw === 'string') {
          freight = freightRaw;
        } else if (freightRaw.valuesByLinkedRecordId) {
          const vals = Object.values(freightRaw.valuesByLinkedRecordId);
          if (vals.length > 0 && Array.isArray(vals[0]) && vals[0].length > 0) {
            freight = vals[0][0].name || '';
          }
        }
      }

      // Status: singleSelect object
      const statusRaw = f['fldQUXBo2smwtjFgX'];
      const status = statusRaw && typeof statusRaw === 'object'
        ? statusRaw.name || ''
        : statusRaw || '';

      return {
        shId:      f['fldl6RM0TkX4GFrZF'] || '',
        liRef:     f['fldLwZ53Zc4MO59OU'] || '',
        dest,
        status,
        eta:       f['fldBdrLERHs7kK6L9'] || null,
        freight,
        unitsDue:  parseFloat(f['fldB1m2fWiZobPVeM'] || 0),
        unitsRcvd: parseFloat(f['fldJtOiIWBFRbrDpD'] || 0),
      };
    });

    return new Response(
      JSON.stringify({ shipments, total: shipments.length }),
      { status: 200, headers: corsHeaders }
    );

  } catch (err) {
    console.error('Airtable fetch error:', err);
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: corsHeaders }
    );
  }
}
