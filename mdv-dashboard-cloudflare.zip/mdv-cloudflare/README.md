# MDV Global Delivery Intelligence — Cloudflare Pages Deployment

## Folder Structure

```
mdv-cloudflare/
├── wrangler.toml               # Cloudflare config
├── public/
│   └── index.html              # The dashboard (served as the site)
└── functions/
    └── api/
        └── shipments.js        # Cloudflare Pages Function → Airtable API
```

## Deploy to Cloudflare Pages

### Step 1 — Push to GitHub
Create a new GitHub repo and push this folder:
```bash
git init
git add .
git commit -m "MDV Delivery Dashboard"
git remote add origin https://github.com/YOUR_USERNAME/mdv-cloudflare.git
git push -u origin main
```

### Step 2 — Connect to Cloudflare Pages
1. Go to https://dash.cloudflare.com → **Workers & Pages** → **Create application**
2. Select **Pages** → **Connect to Git**
3. Select your GitHub repo
4. Build settings:
   - **Framework preset:** None
   - **Build command:** *(leave blank)*
   - **Build output directory:** `public`
5. Click **Save and Deploy**

### Step 3 — Add your Airtable API key
1. In Cloudflare Pages, go to your project → **Settings → Environment variables**
2. Click **Add variable** under **Production**:
   - **Variable name:** `AIRTABLE_API_KEY`
   - **Value:** Your Airtable personal access token
     (Get it from: https://airtable.com/create/tokens)
3. The token needs **data.records:read** scope on the `MDV - Production & Delivery` base
4. Click **Save** → then **Deployments** → **Retry deployment**

### Step 4 — Done
Your dashboard will be live at `https://mdv-delivery-dashboard.pages.dev`
(or a custom domain if you add one via Cloudflare DNS)

## How it works
- The HTML (`public/index.html`) calls `/api/shipments`
- The Cloudflare Pages Function (`functions/api/shipments.js`) calls Airtable's REST API
  using your API key stored securely as a Cloudflare environment variable
- The API key is never exposed to the browser
- Cloudflare's edge network means fast load times globally

## Custom Domain (optional)
1. In Cloudflare Pages → your project → **Custom domains**
2. Add your domain (e.g. `delivery.manierdevoir.com`)
3. Since you're already on Cloudflare, DNS updates automatically

## Sharing with warehouse teams
Just send them the Pages URL. No login required.
The **↺ Refresh** button pulls fresh data from Airtable at any time.
The **↓ Export** button downloads a formatted Excel file.
